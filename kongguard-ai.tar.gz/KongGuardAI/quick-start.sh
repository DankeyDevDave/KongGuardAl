#!/bin/bash

# Quick start script - launches Kong Guard AI with default settings
cd "$(dirname "$0")"
./launch-kong-guard.sh "$@"