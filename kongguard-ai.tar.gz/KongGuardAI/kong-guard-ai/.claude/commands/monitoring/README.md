# Monitoring Commands

Commands for monitoring operations in Claude Flow.

## Available Commands

- [swarm-monitor](./swarm-monitor.md)
- [agent-metrics](./agent-metrics.md)
- [real-time-view](./real-time-view.md)
